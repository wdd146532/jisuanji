export const MODEL_SKELETON_ENUM = {
  WireframeMaterial: '线框材质',
  ColorMaterial: '颜色材质',
} as const
