<template>
  <div>src/views/Dashboard/index.vue</div>
</template>
<script setup lang="ts">
interface PropsType {}
const props = defineProps<PropsType>()
</script>
